vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 Jul 2011 19:47:23 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{9334866C-BF5A-4EFA-8217-136578DADAD2}
vti_cacheddtm:TX|06 Jul 2011 09:38:22 -0000
vti_filesize:IR|2719
vti_backlinkinfo:VX|
vti_modifiedby:SR|WSMAIN3\\rr
